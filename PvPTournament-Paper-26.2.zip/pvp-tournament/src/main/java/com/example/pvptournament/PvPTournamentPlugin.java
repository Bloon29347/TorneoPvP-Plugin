package com.example.pvptournament;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.stream.Collectors;

public final class PvPTournamentPlugin extends JavaPlugin implements Listener {
    private final List<UUID> entrants = new ArrayList<>();
    private final List<UUID> waitingWinners = new ArrayList<>();
    private final Deque<UUID> pendingPlayers = new ArrayDeque<>();
    private final List<UUID> roundWinners = new ArrayList<>();
    private final Map<UUID, Set<String>> picks = new HashMap<>();
    private final Map<UUID, Integer> scores = new HashMap<>();
    private final Map<String, List<ItemStack>> savedKits = new HashMap<>();
    private final Map<UUID, UUID> opponent = new HashMap<>();
    private final Set<UUID> countdown = new HashSet<>();
    private List<String> roundModes = new ArrayList<>();
    private UUID p1, p2;
    private int round = 0;
    private boolean running = false;
    private boolean matchLive = false;
    private boolean selecting = false;
    private BukkitTask countdownTask;

    @Override public void onEnable() {
        saveDefaultConfig();
        loadKits();
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("PvPTournament listo. Usa /torneo ayuda");
    }

    private void loadKits() {
        ConfigurationSection section = getConfig().getConfigurationSection("kits");
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            Object raw = section.get(key);
            if (raw instanceof List<?> list) {
                List<ItemStack> items = new ArrayList<>();
                for (Object item : list) if (item instanceof ItemStack stack) items.add(stack);
                savedKits.put(key.toLowerCase(Locale.ROOT), items);
            }
        }
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("ayuda")) {
            sender.sendMessage(color("&6&lPvP TORNEO &7- Comandos"));
            sender.sendMessage(color("&e/torneo agregar <jugador> &7- Añade un jugador conectado"));
            sender.sendMessage(color("&e/torneo quitar <jugador> &7- Quita un participante antes de empezar"));
            sender.sendMessage(color("&e/torneo kit guardar <nombre> &7- Guarda tu inventario como kit"));
            sender.sendMessage(color("&e/torneo kit modo <modo> <kit> &7- Asigna un kit guardado a un modo"));
            sender.sendMessage(color("&e/torneo iniciar &7- Inicia el torneo (mínimo 2, máximo 16)"));
            sender.sendMessage(color("&e/torneo elegir <modo> &7- Elige un modo durante la votación"));
            sender.sendMessage(color("&e/torneo cancelar &7- Cancela el torneo"));
            sender.sendMessage(color("&7Configura los cinco modos y las posiciones en plugins/PvPTournament/config.yml"));
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("elegir")) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Solo jugadores pueden elegir modos."); return true; }
            if (!selecting || !isCurrentFighter(player.getUniqueId())) { player.sendMessage(color("&cNo estás en una fase de elección.")); return true; }
            if (args.length < 2) { player.sendMessage(color("&eUsa /torneo elegir <modo>")); return true; }
            String mode = findMode(String.join(" ", Arrays.copyOfRange(args, 1, args.length)));
            if (mode == null) { player.sendMessage(color("&cEse modo no existe. Modos: &f" + String.join(", ", getModes()))); return true; }
            Set<String> chosen = picks.computeIfAbsent(player.getUniqueId(), k -> new LinkedHashSet<>());
            if (chosen.contains(mode)) { chosen.remove(mode); player.sendMessage(color("&eQuitaste &f" + mode + "&e de tu selección.")); }
            else if (chosen.size() >= 3) { player.sendMessage(color("&cYa elegiste 3 modos. Vuelve a usar /torneo elegir <modo> para quitar uno.")); return true; }
            else { chosen.add(mode); player.sendMessage(color("&aElegiste &f" + mode + " &7(" + chosen.size() + "/3)")); }
            player.sendMessage(color("&7Tu selección: &f" + (chosen.isEmpty() ? "ninguna" : String.join(", ", chosen))));
            checkPicks();
            return true;
        }
        if (!sender.hasPermission("pvptournament.admin")) { sender.sendMessage(color("&cNecesitas permiso pvptournament.admin.")); return true; }
        switch (sub) {
            case "agregar", "add" -> {
                if (running) { sender.sendMessage(color("&cEl torneo ya empezó.")); return true; }
                if (args.length < 2) { sender.sendMessage("Uso: /torneo agregar <jugador>"); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage(color("&cEl jugador debe estar conectado.")); return true; }
                int max = Math.min(16, getConfig().getInt("max-participants", 16));
                if (entrants.contains(target.getUniqueId())) { sender.sendMessage(color("&eEse jugador ya está registrado.")); return true; }
                if (entrants.size() >= max) { sender.sendMessage(color("&cEl torneo está lleno (" + max + ").")); return true; }
                entrants.add(target.getUniqueId());
                broadcast(color("&a" + target.getName() + " &7se registró (&f" + entrants.size() + "/" + max + "&7)."));
            }
            case "quitar", "remove" -> {
                if (running || args.length < 2) { sender.sendMessage("Uso: /torneo quitar <jugador> (antes de iniciar)"); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null || !entrants.remove(target.getUniqueId())) sender.sendMessage(color("&cNo se encontró ese participante conectado."));
                else broadcast(color("&e" + target.getName() + " fue quitado del torneo."));
            }
            case "kit" -> handleKit(sender, args);
            case "iniciar", "start" -> startTournament(sender);
            case "cancelar", "cancel" -> cancelTournament(sender);
            default -> sender.sendMessage(color("&cComando desconocido. Usa /torneo ayuda"));
        }
        return true;
    }

    private void handleKit(CommandSender sender, String[] args) {
        if (args.length >= 3 && args[1].equalsIgnoreCase("guardar")) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Solo un jugador puede guardar un kit."); return; }
            String name = args[2].toLowerCase(Locale.ROOT);
            List<ItemStack> contents = Arrays.stream(player.getInventory().getContents()).map(i -> i == null ? null : i.clone()).collect(Collectors.toCollection(ArrayList::new));
            savedKits.put(name, contents);
            getConfig().set("kits." + name, contents);
            saveConfig();
            player.sendMessage(color("&aKit &f" + name + " &aguardado desde tu inventario."));
        } else if (args.length >= 4 && args[1].equalsIgnoreCase("modo")) {
            String mode = findMode(args[2]);
            if (mode == null) { sender.sendMessage(color("&cModo no válido. Revisa config.yml.")); return; }
            String kit = args[3].toLowerCase(Locale.ROOT);
            if (!savedKits.containsKey(kit)) { sender.sendMessage(color("&cNo existe el kit " + kit + ". Guárdalo primero.")); return; }
            getConfig().set("mode-kits." + mode, kit); saveConfig();
            sender.sendMessage(color("&aModo &f" + mode + " &ausará el kit &f" + kit + "&a."));
        } else sender.sendMessage("Uso: /torneo kit guardar <nombre> | /torneo kit modo <modo> <kit>");
    }

    private void startTournament(CommandSender sender) {
        if (running) { sender.sendMessage(color("&cYa hay un torneo en curso.")); return; }
        if (entrants.size() < 2) { sender.sendMessage(color("&cAñade al menos 2 jugadores.")); return; }
        if (getModes().size() != 5) { sender.sendMessage(color("&cDebes configurar exactamente cinco modos en config.yml.")); return; }
        running = true; waitingWinners.clear(); pendingPlayers.clear(); roundWinners.clear(); pendingPlayers.addAll(entrants); entrants.clear();
        List<UUID> shuffled = new ArrayList<>(pendingPlayers); pendingPlayers.clear(); Collections.shuffle(shuffled); pendingPlayers.addAll(shuffled);
        broadcast(color("&6&l¡TORNEO PvP INICIADO! &eParticipantes: " + pendingPlayers.size() + ". Eliminación directa."));
        nextMatch();
    }

    private void nextMatch() {
        if (!running) return;
        if (p1 != null || p2 != null) { p1 = null; p2 = null; }
        if (pendingPlayers.isEmpty()) {
            if (roundWinners.size() == 1) {
                Player champ = Bukkit.getPlayer(roundWinners.get(0));
                broadcast(color("&6&l¡CAMPEÓN DEL TORNEO: &e" + (champ == null ? "jugador desconectado" : champ.getName()) + " &6&l!"));
                running = false; matchLive = false; selecting = false; roundWinners.clear(); return;
            }
            if (roundWinners.isEmpty()) { running = false; return; }
            pendingPlayers.addAll(roundWinners); roundWinners.clear();
            broadcast(color("&6Nueva fase del torneo: &e" + pendingPlayers.size() + " jugadores restantes."));
        }
        while (pendingPlayers.size() >= 2 && (p1 == null || p2 == null)) {
            UUID first = pendingPlayers.pollFirst(); UUID second = pendingPlayers.pollFirst();
            if (Bukkit.getPlayer(first) == null) { if (Bukkit.getPlayer(second) != null) roundWinners.add(second); continue; }
            if (Bukkit.getPlayer(second) == null) { roundWinners.add(first); continue; }
            p1 = first; p2 = second;
        }
        if (p1 == null || p2 == null) {
            if (!pendingPlayers.isEmpty()) roundWinners.add(pendingPlayers.pollFirst());
            nextMatch(); return;
        }
        Player a = Bukkit.getPlayer(p1), b = Bukkit.getPlayer(p2);
        round = 0; scores.clear(); scores.put(p1, 0); scores.put(p2, 0); picks.clear(); roundModes.clear(); selecting = true; matchLive = false;
        opponent.put(p1, p2); opponent.put(p2, p1);
        broadcast(color("&d&lENFRENTAMIENTO &f" + a.getName() + " &dvs &f" + b.getName()));
        broadcast(color("&eCada jugador debe elegir 3 de estos 5 modos con &f/torneo elegir <modo>&e:"));
        for (String mode : getModes()) broadcast(color("&b• &f" + mode));
        a.sendMessage(color("&eElige tres modos. Puedes quitar uno repitiendo el comando."));
        b.sendMessage(color("&eElige tres modos. Puedes quitar uno repitiendo el comando."));
    }

    private void checkPicks() {
        if (p1 == null || p2 == null) return;
        Set<String> a = picks.getOrDefault(p1, Set.of()), b = picks.getOrDefault(p2, Set.of());
        if (a.size() != 3 || b.size() != 3) return;
        List<String> modes = getModes();
        modes.sort((x, y) -> Integer.compare((b.contains(y) ? 1 : 0) + (a.contains(y) ? 1 : 0), (b.contains(x) ? 1 : 0) + (a.contains(x) ? 1 : 0)));
        // Desempate estable según el orden configurado; quedan exactamente tres modos.
        roundModes = new ArrayList<>(modes.subList(0, 3));
        selecting = false;
        broadcast(color("&aModos seleccionados para el combate: &f" + String.join(" &7, &f", roundModes)));
        startRound();
    }

    private void startRound() {
        if (p1 == null || p2 == null) return;
        if (round >= 3 || scores.getOrDefault(p1, 0) >= 2 || scores.getOrDefault(p2, 0) >= 2) { finishMatch(); return; }
        Player a = Bukkit.getPlayer(p1), b = Bukkit.getPlayer(p2);
        if (a == null || b == null) { finishByDisconnect(); return; }
        String mode = roundModes.get(round);
        broadcast(color("&dRonda " + (round + 1) + "/3 &7- Modo: &f" + mode));
        teleportToArena(a, "player1"); teleportToArena(b, "player2");
        equipForMode(a, mode); equipForMode(b, mode);
        a.setHealth(20); a.setFoodLevel(20); a.setFireTicks(0); a.setVelocity(new org.bukkit.util.Vector(0,0,0));
        b.setHealth(20); b.setFoodLevel(20); b.setFireTicks(0); b.setVelocity(new org.bukkit.util.Vector(0,0,0));
        countdown.add(p1); countdown.add(p2); matchLive = false;
        final int[] count = {3};
        if (countdownTask != null) countdownTask.cancel();
        countdownTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (a.isOnline()) a.sendTitle(color("&e" + count[0]), color("&7Prepárate"), 0, 20, 0);
            if (b.isOnline()) b.sendTitle(color("&e" + count[0]), color("&7Prepárate"), 0, 20, 0);
            if (count[0] <= 1) {
                countdownTask.cancel(); countdown.remove(p1); countdown.remove(p2); matchLive = true;
                broadcast(color("&c&l¡PELEEN!"));
            }
            count[0]--;
        }, 0L, 20L);
    }

    private void finishMatch() {
        UUID winner = scores.getOrDefault(p1, 0) > scores.getOrDefault(p2, 0) ? p1 : p2;
        Player wp = Bukkit.getPlayer(winner), loser = Bukkit.getPlayer(winner.equals(p1) ? p2 : p1);
        broadcast(color("&aGanador del duelo: &f" + (wp == null ? "jugador" : wp.getName()) + " &7(" + scores.getOrDefault(winner, 0) + " rondas ganadas)"));
        if (wp != null) roundWinners.add(winner);
        if (loser != null) { loser.setHealth(20); loser.setFoodLevel(20); }
        p1 = null; p2 = null; matchLive = false; selecting = false; picks.clear(); scores.clear();
        Bukkit.getScheduler().runTaskLater(this, this::nextMatch, 60L);
    }

    private void finishByDisconnect() {
        UUID winner = Bukkit.getPlayer(p1) != null ? p1 : (Bukkit.getPlayer(p2) != null ? p2 : null);
        if (winner != null) { roundWinners.add(winner); Player p = Bukkit.getPlayer(winner); broadcast(color("&eEl rival se desconectó. Avanza &f" + (p == null ? "el jugador restante" : p.getName()) + "&e.")); }
        p1 = null; p2 = null; matchLive = false; selecting = false;
        Bukkit.getScheduler().runTaskLater(this, this::nextMatch, 40L);
    }

    private void cancelTournament(CommandSender sender) {
        if (countdownTask != null) countdownTask.cancel();
        running = false; matchLive = false; selecting = false; countdown.clear(); picks.clear(); scores.clear(); opponent.clear(); waitingWinners.clear(); pendingPlayers.clear(); roundWinners.clear(); entrants.clear(); p1 = null; p2 = null;
        sender.sendMessage(color("&cTorneo cancelado."));
    }

    @EventHandler public void onDeath(PlayerDeathEvent event) {
        UUID dead = event.getEntity().getUniqueId();
        if (!running || (dead.equals(p1) == false && dead.equals(p2) == false)) return;
        event.setDeathMessage(null);
        UUID winner = dead.equals(p1) ? p2 : p1;
        scores.put(winner, scores.getOrDefault(winner, 0) + 1);
        Player wp = Bukkit.getPlayer(winner);
        broadcast(color("&aRonda para &f" + (wp == null ? "rival" : wp.getName()) + " &7- marcador &f" + scores.getOrDefault(p1,0) + " &7: &f" + scores.getOrDefault(p2,0)));
        matchLive = false;
        Bukkit.getScheduler().runTaskLater(this, () -> {
            Player loser = Bukkit.getPlayer(dead);
            if (loser != null && loser.isOnline()) { loser.spigot().respawn(); }
            if (scores.getOrDefault(winner, 0) >= 2 || scores.getOrDefault(dead, 0) >= 2 || round >= 2) finishMatch();
            else { round++; startRound(); }
        }, 2L);
    }

    @EventHandler public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        if (countdown.contains(victim.getUniqueId())) { event.setCancelled(true); return; }
        if (event.getDamager() instanceof Player attacker && running && (isCurrentFighter(attacker.getUniqueId()) || isCurrentFighter(victim.getUniqueId())) && !matchLive) event.setCancelled(true);
    }
    @EventHandler public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        if (running && (id.equals(p1) || id.equals(p2))) Bukkit.getScheduler().runTaskLater(this, this::finishByDisconnect, 1L);
    }
    @EventHandler public void onChat(AsyncPlayerChatEvent event) {
        if (selecting && isCurrentFighter(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(color("&eElige los modos con /torneo elegir <modo>. Modos: &f" + String.join(", ", getModes())));
        }
    }

    private void equipForMode(Player player, String mode) {
        String kitName = getConfig().getString("mode-kits." + mode, "default").toLowerCase(Locale.ROOT);
        List<ItemStack> kit = savedKits.get(kitName);
        if (kit == null) { player.sendMessage(color("&cNo existe el kit '&f" + kitName + "&c'. Se conservará tu equipo actual.")); return; }
        player.getInventory().clear(); player.getInventory().setArmorContents(null); player.getInventory().setExtraContents(null);
        for (int i = 0; i < Math.min(kit.size(), player.getInventory().getSize()); i++) {
            ItemStack item = kit.get(i); if (item != null) player.getInventory().setItem(i, item.clone());
        }
        player.updateInventory();
    }

    private void teleportToArena(Player player, String key) {
        String worldName = getConfig().getString("arena.world", "world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) { player.sendMessage(color("&cNo existe el mundo de arena '&f" + worldName + "&c'.")); return; }
        String path = "arena." + key + ".";
        Location loc = new Location(world, getConfig().getDouble(path + "x", 0.5), getConfig().getDouble(path + "y", 80), getConfig().getDouble(path + "z", 0.5), (float)getConfig().getDouble(path + "yaw", 0), (float)getConfig().getDouble(path + "pitch", 0));
        player.teleport(loc);
    }
    private boolean isCurrentFighter(UUID id) { return id.equals(p1) || id.equals(p2); }
    private List<String> getModes() { return new ArrayList<>(getConfig().getStringList("modes")); }
    private String findMode(String input) { return getModes().stream().filter(m -> m.equalsIgnoreCase(input)).findFirst().orElse(null); }
    private void broadcast(String message) { Bukkit.broadcastMessage(message); }
    private String color(String text) { return ChatColor.translateAlternateColorCodes('&', text); }
}
