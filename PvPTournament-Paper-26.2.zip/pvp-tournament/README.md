# PvPTournament

Plugin base para torneos PvP de Minecraft con eliminación directa, hasta 16 participantes, cinco modos configurables, elección de tres modos por jugador, kits guardados y asignables por modo, cuenta atrás de tres segundos y duelos al mejor de tres rondas.

## Requisitos
- Java 25 para compilar este proyecto.
- Servidor Paper. El `pom.xml` está configurado con la API `26.2.build.129-stable` como dependencia fijada de la API Paper 26.2. El descriptor del plugin declara `api-version: 26.2`.
- Maven 3.9+.

## Compilar
Desde esta carpeta:

```bash
mvn clean package
```

Copia `target/pvp-tournament-1.0.1.jar` a `plugins/` y reinicia el servidor.

## Configuración
Edita `plugins/PvPTournament/config.yml`:
- `max-participants`: máximo, limitado en código a 16.
- `modes`: exactamente cinco nombres de modo.
- `arena.world`, `arena.player1` y `arena.player2`: mundo y coordenadas de los dos puntos de aparición.

Reinicia el servidor después de editar la configuración.

## Comandos
- `/torneo ayuda`
- `/torneo agregar <jugador>` — el jugador debe estar conectado.
- `/torneo quitar <jugador>` — antes de iniciar.
- `/torneo kit guardar <nombre>` — ejecuta como jugador con el inventario equipado que quieres guardar.
- `/torneo kit modo <modo> <kit>` — asigna un kit guardado a un modo.
- `/torneo iniciar`
- `/torneo elegir <modo>` — durante la fase de elección; repite el modo para quitarlo.
- `/torneo cancelar`

## Nota sobre la elección de modos
Cada contendiente selecciona tres modos. El plugin combina las selecciones por votos y elige los tres modos con más votos; los empates siguen el orden definido en `modes`. Las rondas se juegan en ese orden.

## Alcance de esta versión
Es una primera versión funcional de referencia, no una compilación validada contra Paper 26.2. Pruébala en un servidor de pruebas antes de instalarla en producción. Se recomienda añadir restauración del inventario original, salida/retorno a lobby, protección de la arena y pruebas específicas de respawn para la versión exacta del servidor.
