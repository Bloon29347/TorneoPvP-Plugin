# PvPTournament 2.1.0 — proyecto fuente

Plugin de torneos PvP para Paper, preparado para compilarse con Java 25 desde GitHub Actions. Este ZIP contiene **código fuente**, no un `.jar` listo para instalar.

## Cómo obtener el plugin `.jar`
1. Descarga y descomprime este ZIP en tu dispositivo.
2. Sube **el contenido descomprimido** al repositorio de GitHub. En la raíz del repositorio deben verse `pom.xml`, `src/` y `.github/workflows/build.yml`. No subas solamente el ZIP como un archivo.
3. Abre la pestaña **Actions** del repositorio y entra al flujo **Build PvPTournament**.
4. Espera a que la ejecución termine en verde.
5. En esa ejecución, descarga el artefacto `PvPTournament-JAR` y extrae el `.jar`.
6. Copia el `.jar` a la carpeta `plugins/` de tu servidor Paper y reinicia el servidor.

El workflow ejecuta `mvn clean package` con JDK 25 y adjunta `target/*.jar` como artefacto. La compilación real se verifica en GitHub Actions; este entorno no dispone de JDK 25 ni Maven, así que no voy a afirmar que el `.jar` ya fue compilado aquí.

## Funciones incluidas en esta versión
- Inscripción y retirada de participantes; lista de inscritos y límite configurable (16 por defecto).
- Cuadro de eliminación directa, cola de enfrentamientos y avance de ganadores entre rondas, incluyendo pase automático si queda un número impar.
- Combates al mejor de tres rondas con cuenta atrás de tres segundos y anuncios mediante títulos/subtítulos.
- Menú gráfico para seleccionar tres de cinco modos; en cada enfrentamiento se escoge aleatoriamente uno de los tres seleccionados y se aplican reglas básicas para Sword, Axe, Bow y UHC.
- Menú de selección de kits y editor gráfico de kits con guardar/cancelar; permisos de organizador/admin.
- Arenas configurables con spawn1, spawn2 y punto de espectador por arena; lobby configurable.
- Espectador, estadísticas, recompensas por comandos, autocompletado y controles básicos contra abuso durante el combate.
- Guardado de participantes, cuadro y colas para recuperar un torneo interrumpido; un combate activo se devuelve a la cola para volver a jugarlo tras reiniciar.

## Comandos
- `/pvp ayuda`
- `/pvp participante añadir <jugador>`
- `/pvp participante quitar <jugador>`
- `/pvp participante lista`
- `/pvp kit` — selector de kit
- `/pvp kit crear <nombre>` — crear kit en el editor gráfico
- `/pvp kit editar <nombre>`
- `/pvp kit eliminar <nombre>`
- `/pvp arena <nombre> spawn1`
- `/pvp arena <nombre> spawn2`
- `/pvp arena <nombre> espectador`
- `/pvp arena <nombre> eliminar`
- `/pvp spawn lobby`
- `/pvp modo` — seleccionar tres modos antes de iniciar
- `/pvp iniciar`
- `/pvp cancelar`
- `/pvp reanudar`
- `/pvp cuadro`
- `/pvp estadisticas`
- `/pvp espectar`
- `/pvp lobby`

## Permisos
- `pvptournament.admin`: administración completa (OP por defecto).
- `pvptournament.organizer`: organizar torneo, administrar arenas/kits y seleccionar modos (OP por defecto).

## Nota de compatibilidad
La versión de Paper API declarada en `pom.xml` es `26.2.build.129-stable`, conforme al objetivo solicitado. Si GitHub Actions falla al resolver esa dependencia, abre el log de compilación: puede ser necesario ajustar la versión exacta de Paper publicada en el repositorio Maven. Antes de usarlo en producción, prueba la versión compilada en un servidor de pruebas, especialmente la muerte/respawn y recuperación tras reinicios.
