package com.jangel.pvptournament;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public final class PvPTournament extends JavaPlugin implements Listener, TabExecutor {
    private static final String KITS_TITLE = ChatColor.DARK_AQUA + "PvP | Kits";
    private static final String MODES_TITLE = ChatColor.DARK_PURPLE + "PvP | Elige 3 modos";
    private static final String EDIT_PREFIX = ChatColor.DARK_GREEN + "PvP | Editar kit | ";
    private static final String ARENA_PREFIX = ChatColor.BLUE + "PvP | Arenas";
    private final LinkedHashSet<UUID> participants = new LinkedHashSet<>();
    private final Map<UUID, ItemStack[]> inventoryBackup = new HashMap<>();
    private final Map<UUID, ItemStack[]> armorBackup = new HashMap<>();
    private final Map<UUID, ItemStack> offhandBackup = new HashMap<>();
    private final Map<UUID, GameMode> gameModeBackup = new HashMap<>();
    private final Map<UUID, Float> expBackup = new HashMap<>();
    private final Map<UUID, Integer> levelBackup = new HashMap<>();
    private final Map<UUID, String> kitEditing = new HashMap<>();
    private final Map<UUID, Set<String>> modeChoices = new HashMap<>();
    private final Map<UUID, String> playerKits = new HashMap<>();
    private final Map<UUID, UUID> opponents = new HashMap<>();
    private final Map<UUID, Integer> roundWins = new HashMap<>();
    private final Map<UUID, String> matchArena = new HashMap<>();
    private final Set<UUID> spectators = new HashSet<>();
    private final List<List<UUID>> rounds = new ArrayList<>();
    private final List<UUID> matchQueue = new ArrayList<>();
    private final List<UUID> nextQueue = new ArrayList<>();
    private int roundIndex = 0;
    private boolean running = false, matchLive = false, selectingModes = false;
    private UUID playerOne, playerTwo;
    private String activeArena = null;
    private String activeMode = "Classic";
    private final List<String> modes = new ArrayList<>(List.of("Sword", "Axe", "Bow", "UHC", "Classic"));

    @Override public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("pvp")).setExecutor(this);
        Objects.requireNonNull(getCommand("pvp")).setTabCompleter(this);
        modes.clear(); modes.addAll(getConfig().getStringList("settings.mode-names"));
        if (modes.size() != 5) { modes.clear(); modes.addAll(List.of("Sword","Axe","Bow","UHC","Classic")); }
        loadState();
        getLogger().info("PvPTournament v2.1 habilitado. Consulta GitHub Actions para verificar la compilación.");
    }
    @Override public void onDisable() { saveState(); restoreAllOnline(); }

    private boolean isAdmin(CommandSender s) { return s.hasPermission("pvptournament.admin") || s.isOp(); }
    private boolean isOrganizer(CommandSender s) { return isAdmin(s) || s.hasPermission("pvptournament.organizer"); }
    private boolean requireOrganizer(CommandSender s) {
        if (isOrganizer(s)) return true;
        s.sendMessage(ChatColor.RED + "Necesitas pvptournament.organizer o pvptournament.admin.");
        return false;
    }
    private void title(Player p, String a, String b) { p.sendTitle(ChatColor.translateAlternateColorCodes('&', a), ChatColor.translateAlternateColorCodes('&', b), 5, 40, 10); }
    private void announce(String a, String b) { for (Player p : Bukkit.getOnlinePlayers()) title(p,a,b); }
    private ItemStack item(Material m, String name, String... lore) {
        ItemStack i = new ItemStack(m); ItemMeta meta = i.getItemMeta();
        if (meta != null) { meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name)); meta.setLore(Arrays.stream(lore).map(s -> ChatColor.translateAlternateColorCodes('&',s)).toList()); i.setItemMeta(meta); }
        return i;
    }
    private String kitPath(String name) { return "kits." + name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]", "_"); }
    private String arenaPath(String name) { return "arenas." + name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]", "_"); }
    private Location loc(String path) { return getConfig().getLocation(path); }
    private void saveState() {
        getConfig().set("tournament.status", running ? "RUNNING" : "IDLE");
        getConfig().set("tournament.participants", participants.stream().map(UUID::toString).toList());
        getConfig().set("tournament.round-index", roundIndex);
        getConfig().set("tournament.bracket", rounds.stream().map(r -> r.stream().map(UUID::toString).toList()).toList());
        getConfig().set("tournament.match-queue", matchQueue.stream().map(UUID::toString).toList());
        getConfig().set("tournament.next-queue", nextQueue.stream().map(UUID::toString).toList());
        getConfig().set("tournament.current-match.player-one", playerOne == null ? null : playerOne.toString());
        getConfig().set("tournament.current-match.player-two", playerTwo == null ? null : playerTwo.toString());
        getConfig().set("tournament.current-match.arena", activeArena);
        getConfig().set("tournament.current-match.mode", activeMode);
        saveConfig();
    }
    private void loadState() {
        for (String s : getConfig().getStringList("tournament.participants")) try { participants.add(UUID.fromString(s)); } catch (Exception ignored) {}
        roundIndex = getConfig().getInt("tournament.round-index",0);
        for (List<?> layer : getConfig().getList("tournament.bracket", List.of())) {
            List<UUID> parsed = new ArrayList<>();
            for (Object value : layer) try { parsed.add(UUID.fromString(String.valueOf(value))); } catch (Exception ignored) {}
            rounds.add(parsed);
        }
        for (String value : getConfig().getStringList("tournament.match-queue")) try { matchQueue.add(UUID.fromString(value)); } catch (Exception ignored) {}
        for (String value : getConfig().getStringList("tournament.next-queue")) try { nextQueue.add(UUID.fromString(value)); } catch (Exception ignored) {}
        if (getConfig().getString("tournament.status","IDLE").equals("RUNNING")) {
            // Put a crashed in-progress match back into the queue so it can be replayed safely.
            try { UUID id = UUID.fromString(getConfig().getString("tournament.current-match.player-one", "")); if (!matchQueue.contains(id)) matchQueue.add(0, id); } catch (Exception ignored) {}
            try { UUID id = UUID.fromString(getConfig().getString("tournament.current-match.player-two", "")); if (!matchQueue.contains(id)) matchQueue.add(Math.min(1, matchQueue.size()), id); } catch (Exception ignored) {}
            running = !participants.isEmpty() && !matchQueue.isEmpty();
            playerOne = null; playerTwo = null; activeArena = null; matchLive = false;
            getConfig().set("tournament.status", running ? "RECOVERED" : "IDLE");
            saveConfig();
            getLogger().warning("Estado del torneo recuperado. Los enfrentamientos interrumpidos se jugarán de nuevo.");
        }
    }
    private void restore(Player p) {
        ItemStack[] old = inventoryBackup.remove(p.getUniqueId());
        if (old != null && getConfig().getBoolean("settings.restore-inventory",true)) {
            p.getInventory().clear();
            for (int i=0;i<Math.min(36,old.length);i++) p.getInventory().setItem(i,old[i]);
        }
        p.setGameMode(GameMode.SURVIVAL);
        p.setHealth(Math.max(1.0, getMaxHealth(p))); p.setFoodLevel(20); p.setFireTicks(0);
        p.setInvulnerable(false);
    }
    private double getMaxHealth(Player p) {
        var attr=p.getAttribute(Attribute.MAX_HEALTH);
        return attr == null ? 20.0 : attr.getValue();
    }
    private void restoreAllOnline() { for (Player p : Bukkit.getOnlinePlayers()) if (inventoryBackup.containsKey(p.getUniqueId())) restore(p); }
    private void saveBackup(Player p) {
        UUID id = p.getUniqueId();
        inventoryBackup.putIfAbsent(id, p.getInventory().getContents());
        armorBackup.putIfAbsent(id, p.getInventory().getArmorContents());
        offhandBackup.putIfAbsent(id, p.getInventory().getItemInOffHand());
        gameModeBackup.putIfAbsent(id, p.getGameMode());
        expBackup.putIfAbsent(id, p.getExp()); levelBackup.putIfAbsent(id, p.getLevel());
    }

    @Override public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (a.length==0 || a[0].equalsIgnoreCase("ayuda")) { help(s); return true; }
        String root=a[0].toLowerCase(Locale.ROOT);
        if (root.equals("kit")) {
            if (a.length==1) { if(s instanceof Player p) openKitMenu(p); else s.sendMessage("Solo jugadores."); return true; }
            if (!requireOrganizer(s)) return true;
            if (!(s instanceof Player p)) { s.sendMessage("Usa este comando dentro del juego."); return true; }
            if (a[1].equalsIgnoreCase("crear") && a.length>=3) { openKitEditor(p,a[2]); return true; }
            if (a[1].equalsIgnoreCase("editar") && a.length>=3) { if(!getConfig().isConfigurationSection(kitPath(a[2]))) { title(p,"&cKit inexistente","&f/pvp kit crear "+a[2]); return true; } openKitEditor(p,a[2]); return true; }
            if (a[1].equalsIgnoreCase("eliminar") && a.length>=3) { getConfig().set(kitPath(a[2]),null); saveConfig(); title(p,"&aKit eliminado","&f"+a[2]); return true; }
            title(p,"&eKits","&fcrear|editar|eliminar <nombre>"); return true;
        }
        if (root.equals("participante") && a.length>=2 && a[1].equalsIgnoreCase("lista")) {
            if (participants.isEmpty()) { s.sendMessage(ChatColor.YELLOW+"No hay participantes inscritos."); return true; }
            s.sendMessage(ChatColor.GOLD+"Participantes ("+participants.size()+"/"+getConfig().getInt("settings.max-participants",16)+"):");
            for (UUID id : participants) { String n=Bukkit.getOfflinePlayer(id).getName(); s.sendMessage(ChatColor.AQUA+"- "+(n==null?id.toString():n)); }
            return true;
        }
        if (root.equals("participante") && a.length>=3 && a[1].equalsIgnoreCase("quitar")) {
            if(!requireOrganizer(s)) return true;
            Player target=Bukkit.getPlayerExact(a[2]);
            UUID id = target == null ? Bukkit.getOfflinePlayer(a[2]).getUniqueId() : target.getUniqueId();
            if (!participants.remove(id)) { s.sendMessage(ChatColor.RED+"Ese jugador no está inscrito."); return true; }
            saveState(); titleIfPlayer(s,"&aParticipante eliminado","&f"+a[2]); if(target!=null) title(target,"&cInscripción cancelada","&fEl organizador te retiró del torneo"); return true;
        }
        if (root.equals("participante") && a.length>=3 && a[1].equalsIgnoreCase("añadir")) {
            if(!requireOrganizer(s)) return true;
            Player target=Bukkit.getPlayerExact(a[2]);
            if(target==null) { s.sendMessage(ChatColor.RED+"El jugador debe estar conectado."); return true; }
            if(participants.size()>=getConfig().getInt("settings.max-participants",16) && !participants.contains(target.getUniqueId())) { s.sendMessage(ChatColor.RED+"Máximo 16 participantes."); return true; }
            participants.add(target.getUniqueId()); saveState(); title(target,"&6¡Inscrito!","&fPrepárate para el torneo"); titleIfPlayer(s,"&aAñadido","&f"+target.getName()); return true;
        }
        if(root.equals("arena") && a.length>=2) {
            if(!requireOrganizer(s)) return true;
            if(!(s instanceof Player p)) { s.sendMessage("Solo dentro del juego."); return true; }
            String name=a[1];
            if(a.length>=3 && a[2].equalsIgnoreCase("spawn1")) return setArenaSpawn(p,name,1);
            if(a.length>=3 && a[2].equalsIgnoreCase("spawn2")) return setArenaSpawn(p,name,2);
            if(a.length>=3 && a[2].equalsIgnoreCase("espectador")) { getConfig().set(arenaPath(name)+".spectator",p.getLocation()); saveConfig(); title(p,"&aSpawn espectador guardado","&f"+name); return true; }
            if(a.length>=3 && a[2].equalsIgnoreCase("eliminar")) { getConfig().set(arenaPath(name),null); saveConfig(); title(p,"&aArena eliminada","&f"+name); return true; }
            title(p,"&eConfigurar arena","&f/pvp arena <nombre> spawn1|spawn2"); return true;
        }
        if(root.equals("spawn") && a.length>=2) {
            if(!requireOrganizer(s)) return true;
            if(!(s instanceof Player p)) { s.sendMessage("Solo dentro del juego."); return true; }
            getConfig().set("locations."+a[1].toLowerCase(Locale.ROOT),p.getLocation()); saveConfig(); title(p,"&aSpawn guardado","&f"+a[1]); return true;
        }
        if(root.equals("modo")) {
            if(!requireOrganizer(s)) return true;
            if(!(s instanceof Player p)) { s.sendMessage("Solo jugadores."); return true; }
            if(running && matchLive) { title(p,"&cTorneo en marcha","&fNo cambies los modos durante un combate"); return true; }
            openModeMenu(p); return true;
        }
        if(root.equals("iniciar")) {
            if(!requireOrganizer(s)) return true;
            if(running) { s.sendMessage(ChatColor.RED+"Ya hay un torneo activo."); return true; }
            List<UUID> eligible=participants.stream().filter(id->Bukkit.getPlayer(id)!=null).toList();
            if(eligible.size()<2) { s.sendMessage(ChatColor.RED+"Necesitas al menos 2 participantes conectados."); return true; }
            if(eligible.size()>getConfig().getInt("settings.max-participants",16)) { s.sendMessage(ChatColor.RED+"Máximo "+getConfig().getInt("settings.max-participants",16)+" participantes."); return true; }
            if(firstAvailableArena()==null) { s.sendMessage(ChatColor.RED+"Configura al menos una arena con /pvp arena <nombre> spawn1 y spawn2."); return true; }
            List<String> selectedModes = getConfig().getStringList("tournament.selected-modes");
            if(selectedModes.size()!=3) { s.sendMessage(ChatColor.RED+"El organizador debe elegir 3 modos con /pvp modo antes de iniciar."); return true; }
            participants.clear(); participants.addAll(eligible); rounds.clear(); rounds.add(new ArrayList<>(eligible)); matchQueue.clear(); matchQueue.addAll(eligible); nextQueue.clear(); roundIndex=0; running=true; saveState();
            announce("&6¡TORNEO PVP!","&fCuadro creado: "+eligible.size()+" participantes");
            startNextMatch(); return true;
        }
        if(root.equals("cancelar")) { if(!requireOrganizer(s)) return true; finishTournament(null); return true; }
        if(root.equals("lobby")) {
            if (!(s instanceof Player p)) return true;
            Location lobby = loc("locations.lobby");
            if (lobby == null) { title(p, "&cLobby sin configurar", "&f/pvp spawn lobby"); return true; }
            if (matchLive && (Objects.equals(p.getUniqueId(), playerOne) || Objects.equals(p.getUniqueId(), playerTwo))) { title(p, "&cNo puedes salir", "&fEl combate está activo"); return true; }
            restore(p); p.teleport(lobby); title(p, "&aLobby", "&fHas regresado al lobby"); return true;
        }
        if(root.equals("espectar")) {
            if(!(s instanceof Player p)) return true;
            if(!running || playerOne==null) { title(p,"&cNo hay combate","&fNo hay un enfrentamiento activo"); return true; }
            spectators.add(p.getUniqueId()); saveBackup(p); p.setGameMode(GameMode.SPECTATOR);
            if(activeArena!=null) { Location s1=loc(arenaPath(activeArena)+".spectator"); if(s1!=null) p.teleport(s1); else { Player target = Bukkit.getPlayer(playerOne); if (target != null) p.teleport(target.getLocation()); } }
            title(p,"&bModo espectador","&fEstás viendo el enfrentamiento"); return true;
        }
        if(root.equals("estadisticas")) { showStats(s); return true; }
        if(root.equals("cuadro")) { showBracket(s); return true; }
        if(root.equals("reanudar")) { if(!requireOrganizer(s)) return true; if(running) startNextMatch(); else s.sendMessage("No hay torneo activo guardado. Usa /pvp iniciar."); return true; }
        help(s); return true;
    }
    private void titleIfPlayer(CommandSender s,String a,String b) { if(s instanceof Player p) title(p,a,b); else s.sendMessage(ChatColor.stripColor(a)+" "+ChatColor.stripColor(b)); }
    private boolean setArenaSpawn(Player p,String name,int n) { String path=arenaPath(name)+".spawn"+n; getConfig().set(path,p.getLocation()); saveConfig(); title(p,"&aSpawn guardado", "&f"+name+" / spawn"+n); return true; }
    private void help(CommandSender s) {
        s.sendMessage(ChatColor.GOLD+"PvPTournament 2.0 — comandos");
        s.sendMessage(ChatColor.AQUA+"/pvp participante añadir|quitar <jugador> | lista");
        s.sendMessage(ChatColor.AQUA+"/pvp iniciar | cancelar | reanudar | cuadro | estadisticas");
        s.sendMessage(ChatColor.AQUA+"/pvp arena <nombre> spawn1|spawn2|espectador|eliminar");
        s.sendMessage(ChatColor.AQUA+"/pvp spawn lobby|espectador");
        s.sendMessage(ChatColor.AQUA+"/pvp kit [crear|editar|eliminar] <nombre>");
        s.sendMessage(ChatColor.AQUA+"/pvp modo | /pvp espectar | /pvp lobby");
    }
    private void openKitMenu(Player p) {
        Inventory inv=Bukkit.createInventory(null,54,KITS_TITLE);
        ConfigurationSection sec=getConfig().getConfigurationSection("kits"); int slot=0;
        if(sec!=null) for(String key:sec.getKeys(false)) {
            if(slot>=45) break;
            inv.setItem(slot++,item(Material.CHEST,"&b"+key,"&7Clic para seleccionar"));
        }
        inv.setItem(49,item(Material.BARRIER,"&cCerrar"));
        p.openInventory(inv);
    }
    private void openKitEditor(Player p,String name) {
        Inventory inv=Bukkit.createInventory(null,54,EDIT_PREFIX+name);
        ItemStack[] old=(ItemStack[])getConfig().get(kitPath(name)+".contents");
        if(old!=null) for(int i=0;i<Math.min(45,old.length);i++) if(old[i]!=null) inv.setItem(i,old[i]);
        inv.setItem(49,item(Material.EMERALD_BLOCK,"&aGUARDAR KIT","&7Guarda los primeros 45 espacios"));
        inv.setItem(53,item(Material.BARRIER,"&cCancelar"));
        kitEditing.put(p.getUniqueId(),name); p.openInventory(inv);
    }
    private void openModeMenu(Player p) {
        Set<String> selected=modeChoices.computeIfAbsent(p.getUniqueId(),k->new LinkedHashSet<>(getConfig().getStringList("tournament.selected-modes")));
        Inventory inv=Bukkit.createInventory(null,27,MODES_TITLE);
        for(int i=0;i<5;i++) inv.setItem(10+i,item(selected.contains(modes.get(i))?Material.LIME_DYE:Material.GRAY_DYE,(selected.contains(modes.get(i))?"&a":"&e")+modes.get(i),"&7Selecciona hasta 3"));
        inv.setItem(22,item(Material.EMERALD_BLOCK,"&aConfirmar selección","&fSeleccionados: "+selected.size()+"/3"));
        p.openInventory(inv);
    }
    @EventHandler public void onInventoryClick(InventoryClickEvent e) {
        if(!(e.getWhoClicked() instanceof Player p)) return;
        String t=e.getView().getTitle();
        if(t.equals(KITS_TITLE)) {
            e.setCancelled(true); ItemStack clicked=e.getCurrentItem();
            if(clicked==null||!clicked.hasItemMeta()||clicked.getType()==Material.BARRIER) { p.closeInventory(); return; }
            String name=ChatColor.stripColor(clicked.getItemMeta().getDisplayName());
            if(!getConfig().isConfigurationSection(kitPath(name))) return;
            playerKits.put(p.getUniqueId(),name); title(p,"&aKit seleccionado","&f"+name); p.closeInventory(); return;
        }
        if(t.equals(MODES_TITLE)) {
            e.setCancelled(true); ItemStack clicked=e.getCurrentItem(); if(clicked==null) return;
            if(e.getRawSlot()>=10&&e.getRawSlot()<15) {
                String mode=modes.get(e.getRawSlot()-10); Set<String> set=modeChoices.computeIfAbsent(p.getUniqueId(),k->new LinkedHashSet<>());
                if(set.contains(mode)) set.remove(mode); else if(set.size()<3) set.add(mode);
                openModeMenu(p); return;
            }
            if(e.getRawSlot()==22) {
                Set<String> set=modeChoices.getOrDefault(p.getUniqueId(),Set.of());
                if(set.size()!=3) { title(p,"&cElige exactamente 3","&fSeleccionados: "+set.size()+"/3"); return; }
                getConfig().set("tournament.selected-modes",new ArrayList<>(set)); saveConfig();
                title(p,"&aModos guardados","&f"+String.join(", ",set)); p.closeInventory();
            } return;
        }
        if(t.startsWith(EDIT_PREFIX)) {
            String name=kitEditing.get(p.getUniqueId()); if(name==null) { e.setCancelled(true); return; }
            if(e.getRawSlot()==49) {
                e.setCancelled(true); ItemStack[] contents=new ItemStack[45]; for(int i=0;i<45;i++) contents[i]=e.getInventory().getItem(i);
                getConfig().set(kitPath(name)+".contents",contents); saveConfig(); kitEditing.remove(p.getUniqueId()); p.closeInventory(); title(p,"&aKit guardado","&f"+name); return;
            }
            if(e.getRawSlot()==53) { e.setCancelled(true); kitEditing.remove(p.getUniqueId()); p.closeInventory(); title(p,"&eEdición cancelada","&fNo se guardaron cambios"); return; }
            if(e.getRawSlot()>=45) e.setCancelled(true);
        }
    }
    @EventHandler public void onInventoryDrag(InventoryDragEvent e) {
        String t=e.getView().getTitle();
        if(t.equals(KITS_TITLE)||t.equals(MODES_TITLE)) e.setCancelled(true);
        if(t.startsWith(EDIT_PREFIX)&&e.getRawSlots().stream().anyMatch(s->s>=45)) e.setCancelled(true);
    }
    private void startNextMatch() {
        if (!running || (playerOne != null && playerTwo != null)) return;
        // A bye advances automatically when a round has an odd number of entrants.
        if (matchQueue.size() == 1) nextQueue.add(matchQueue.remove(0));
        if (matchQueue.size() < 2) {
            if (nextQueue.size() == 1) { finishTournament(nextQueue.get(0)); return; }
            if (nextQueue.isEmpty()) { finishTournament(null); return; }
            roundIndex++;
            rounds.add(new ArrayList<>(nextQueue));
            matchQueue.addAll(nextQueue);
            nextQueue.clear();
            saveState();
            startNextMatch();
            return;
        }
        playerOne = matchQueue.remove(0);
        playerTwo = matchQueue.remove(0);
        Player p1 = Bukkit.getPlayer(playerOne), p2 = Bukkit.getPlayer(playerTwo);
        if (p1 == null || p2 == null) {
            UUID winner = p1 == null ? playerTwo : playerOne;
            UUID loser = p1 == null ? playerOne : playerTwo;
            nextQueue.add(winner);
            stat(winner, "wins", 1); stat(loser, "losses", 1);
            playerOne = null; playerTwo = null;
            saveState(); startNextMatch(); return;
        }
        if (playerKits.get(playerOne) == null || playerKits.get(playerTwo) == null) {
            title(p1, "&eElige tu kit", "&fUsa /pvp kit"); title(p2, "&eElige tu kit", "&fUsa /pvp kit");
            matchQueue.add(0, playerTwo); matchQueue.add(0, playerOne); playerOne = null; playerTwo = null; return;
        }
        activeArena = firstAvailableArena();
        if (activeArena == null) {
            announce("&cSin arena disponible", "&fConfigura una arena con dos spawns");
            matchQueue.add(0, playerTwo); matchQueue.add(0, playerOne); playerOne = null; playerTwo = null; return;
        }
        List<String> picked = getConfig().getStringList("tournament.selected-modes");
        if (picked.size() != 3) picked = modes.subList(0, 3);
        activeMode = picked.get(new Random().nextInt(picked.size()));
        roundWins.put(playerOne, 0); roundWins.put(playerTwo, 0);
        prepareFighter(p1, playerKits.get(playerOne), arenaPath(activeArena) + ".spawn1", activeMode);
        prepareFighter(p2, playerKits.get(playerTwo), arenaPath(activeArena) + ".spawn2", activeMode);
        opponents.put(playerOne, playerTwo); opponents.put(playerTwo, playerOne);
        matchArena.put(playerOne, activeArena); matchArena.put(playerTwo, activeArena);
        for (int i = 3; i >= 1; i--) {
            final int sec = i;
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (playerOne != null && playerTwo != null) announce("&6" + sec, "&fModo: " + activeMode + " | ¡Combate en " + activeArena + "!");
            }, (3 - i) * 20L);
        }
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (playerOne != null && playerTwo != null) {
                matchLive = true;
                Player a = Bukkit.getPlayer(playerOne), b = Bukkit.getPlayer(playerTwo);
                if (a != null) a.setInvulnerable(false); if (b != null) b.setInvulnerable(false);
                announce("&c¡PELEEN!", "&f" + activeMode + " | Mejor de tres rondas");
            }
        }, 60L);
        saveState();
    }
    private String firstAvailableArena() {
        ConfigurationSection sec=getConfig().getConfigurationSection("arenas"); if(sec==null)return null;
        for(String k:sec.getKeys(false)) if(getConfig().getLocation("arenas."+k+".spawn1")!=null&&getConfig().getLocation("arenas."+k+".spawn2")!=null) return k;
        return null;
    }
    private void prepareFighter(Player p, String kit, String spawnPath, String mode) {
        saveBackup(p); p.getInventory().clear(); p.getInventory().setArmorContents(null); p.setHealth(getMaxHealth(p)); p.setFoodLevel(20); p.setFireTicks(0); p.setGameMode(GameMode.SURVIVAL); p.setInvulnerable(true);

        ItemStack[] contents=(ItemStack[])getConfig().get(kitPath(kit)+".contents");
        if(contents!=null) for(int i=0;i<Math.min(36,contents.length);i++) if(contents[i]!=null) p.getInventory().setItem(i,contents[i]);
        applyModeRules(p, mode);
        Location spawn=loc(spawnPath); if(spawn!=null) p.teleport(spawn);
    }
    private void applyModeRules(Player p, String mode) {
        String m = mode.toLowerCase(Locale.ROOT);
        if (m.contains("sword")) removeMaterials(p, Material.BOW, Material.CROSSBOW, Material.WOODEN_AXE, Material.STONE_AXE, Material.IRON_AXE, Material.GOLDEN_AXE, Material.DIAMOND_AXE, Material.NETHERITE_AXE);
        else if (m.contains("axe")) removeMaterials(p, Material.BOW, Material.CROSSBOW, Material.IRON_SWORD, Material.DIAMOND_SWORD, Material.NETHERITE_SWORD, Material.STONE_SWORD, Material.WOODEN_SWORD, Material.GOLDEN_SWORD);
        else if (m.contains("bow")) removeMaterials(p, Material.IRON_SWORD, Material.DIAMOND_SWORD, Material.NETHERITE_SWORD, Material.STONE_SWORD, Material.WOODEN_SWORD, Material.GOLDEN_SWORD, Material.WOODEN_AXE, Material.STONE_AXE, Material.IRON_AXE, Material.GOLDEN_AXE, Material.DIAMOND_AXE, Material.NETHERITE_AXE);
        else if (m.contains("uhc")) { p.setHealth(getMaxHealth(p)); p.getInventory().addItem(new ItemStack(Material.GOLDEN_APPLE, 2)); }
    }
    private void removeMaterials(Player p, Material... materials) {
        Set<Material> blocked = EnumSet.copyOf(Arrays.asList(materials));
        for (int i = 0; i < p.getInventory().getSize(); i++) {
            ItemStack stack = p.getInventory().getItem(i);
            if (stack != null && blocked.contains(stack.getType())) p.getInventory().setItem(i, null);
        }
    }
    @EventHandler public void onDeath(PlayerDeathEvent e) {
        Player loser=e.getEntity(); UUID id=loser.getUniqueId(); UUID winner=opponents.get(id);
        if(winner==null||!running) return;
        e.getDrops().clear(); e.setDroppedExp(0);
        Bukkit.getScheduler().runTask(this,()-> {
            Player win=Bukkit.getPlayer(winner); if(win!=null) { win.setHealth(getMaxHealth(win)); win.setFoodLevel(20); }
            Player lo=Bukkit.getPlayer(id); if(lo!=null) { lo.spigot().respawn(); }
            recordWin(winner,id);
        });
    }
    private void recordWin(UUID winner,UUID loser) {
        if(playerOne==null||playerTwo==null||!matchLive)return;
        int wins=roundWins.getOrDefault(winner,0)+1; roundWins.put(winner,wins);
        Player wp=Bukkit.getPlayer(winner), lp=Bukkit.getPlayer(loser);
        if(wp!=null) title(wp,"&a¡Ronda ganada!","&f"+wins+" ronda(s)");
        if(lp!=null) title(lp,"&cRonda perdida","&fEl rival ha ganado la ronda");
        matchLive=false;
        if(wins>=2) {
            nextQueue.add(winner);
            stat(winner,"wins",1); stat(loser,"losses",1);
            stat(winner,"matchesWon",1);
            Player a=Bukkit.getPlayer(playerOne), b=Bukkit.getPlayer(playerTwo);
            if(a!=null) restore(a); if(b!=null) restore(b);
            opponents.remove(playerOne); opponents.remove(playerTwo);
            playerOne=null; playerTwo=null; activeArena=null; roundWins.clear();
            Bukkit.getScheduler().runTaskLater(this,this::startNextMatch,60L);
        } else {
            Bukkit.getScheduler().runTaskLater(this,()-> {
                Player a=Bukkit.getPlayer(playerOne), b=Bukkit.getPlayer(playerTwo);
                if(a==null||b==null) { recordWin(a==null?playerTwo:playerOne,a==null?playerOne:playerTwo); return; }
                prepareFighter(a,playerKits.get(playerOne),arenaPath(activeArena)+".spawn1",activeMode);
                prepareFighter(b,playerKits.get(playerTwo),arenaPath(activeArena)+".spawn2",activeMode);
                new BukkitRunnable() { int n=3; public void run() { if(playerOne==null||playerTwo==null){cancel();return;} if(n==0){matchLive=true; announce("&c¡PELEEN!","&fRonda siguiente");cancel();} else {announce("&6"+n,"&fRonda siguiente");n--;} } }.runTaskTimer(PvPTournament.this,0,20);
            },40L);
        }
        saveState();
    }
    private void finishTournament(UUID winner) {
        running=false; matchLive=false;
        if(winner!=null) {
            Player p=Bukkit.getPlayer(winner); String name = p != null ? p.getName() : Bukkit.getOfflinePlayer(winner).getName();
            announce("&6¡CAMPEÓN!","&f"+(name==null?winner.toString():name));
            stat(winner,"tournamentsWon",1);
            for(String cmd:getConfig().getStringList("settings.reward-commands")) Bukkit.dispatchCommand(Bukkit.getConsoleSender(),cmd.replace("%winner%",name==null?winner.toString():name));
        } else announce("&cTorneo cancelado","&fEl organizador canceló el torneo");
        restoreAllOnline(); playerOne=null; playerTwo=null; opponents.clear(); spectators.clear(); activeArena=null; matchQueue.clear(); nextQueue.clear();
        getConfig().set("tournament.status","IDLE"); saveState();
    }
    private void stat(UUID id,String key,int amount) { String path="tournament.stats."+id+"."+key; getConfig().set(path,getConfig().getInt(path,0)+amount); saveConfig(); }
    private void showStats(CommandSender s) {
        s.sendMessage(ChatColor.GOLD+"Estadísticas PvP:");
        ConfigurationSection sec=getConfig().getConfigurationSection("tournament.stats");
        if(sec==null) { s.sendMessage("Aún no hay estadísticas."); return; }
        for(String id:sec.getKeys(false)) s.sendMessage(id+": victorias="+sec.getInt(id+".wins")+" derrotas="+sec.getInt(id+".losses")+" torneos="+sec.getInt(id+".tournamentsWon"));
    }
    private void showBracket(CommandSender s) {
        s.sendMessage(ChatColor.GOLD+"Cuadro PvP — ronda "+(roundIndex+1));
        for(int i=0;i<rounds.size();i++) {
            s.sendMessage(ChatColor.YELLOW+"Ronda "+(i+1)+":");
            for(UUID id:rounds.get(i)) { String name=Bukkit.getOfflinePlayer(id).getName(); s.sendMessage(" • "+(name==null?id.toString():name)); }
        }
    }
    @EventHandler public void onQuit(PlayerQuitEvent e) {
        Player p=e.getPlayer(); UUID id=p.getUniqueId();
        if(opponents.containsKey(id)&&running) {
            UUID opp=opponents.get(id); Bukkit.getScheduler().runTask(this,()->recordWin(opp,id));
        }
        if(spectators.contains(id)) spectators.remove(id);
    }
    @EventHandler public void onMove(PlayerMoveEvent e) {
        Player p=e.getPlayer();
        if(matchLive && (Objects.equals(p.getUniqueId(),playerOne)||Objects.equals(p.getUniqueId(),playerTwo))) return;
        if((Objects.equals(p.getUniqueId(),playerOne)||Objects.equals(p.getUniqueId(),playerTwo)) && !matchLive && e.getTo()!=null && (e.getFrom().getBlockX()!=e.getTo().getBlockX()||e.getFrom().getBlockY()!=e.getTo().getBlockY()||e.getFrom().getBlockZ()!=e.getTo().getBlockZ())) e.setTo(e.getFrom());
    }
    @EventHandler public void onCommand(PlayerCommandPreprocessEvent e) {
        if(!matchLive) return;
        UUID id=e.getPlayer().getUniqueId();
        if(Objects.equals(id,playerOne)||Objects.equals(id,playerTwo)) {
            String cmd=e.getMessage().toLowerCase(Locale.ROOT);
            if(!cmd.startsWith("/msg ")&&!cmd.startsWith("/tell ")&&!cmd.startsWith("/r ")) { e.setCancelled(true); title(e.getPlayer(),"&cComandos bloqueados","&fNo puedes usar comandos durante el combate"); }
        }
    }
    @EventHandler public void onDrop(PlayerDropItemEvent e) {
        if(matchLive&&(Objects.equals(e.getPlayer().getUniqueId(),playerOne)||Objects.equals(e.getPlayer().getUniqueId(),playerTwo))) e.setCancelled(true);
    }
    @EventHandler public void onDamage(org.bukkit.event.entity.EntityDamageByEntityEvent e) {
        if(e.getEntity() instanceof Player victim) {
            UUID v=victim.getUniqueId();
            if(matchLive && (!Objects.equals(v,playerOne)&&!Objects.equals(v,playerTwo))) { e.setCancelled(true); return; }
            if(e.getDamager() instanceof Player attacker && matchLive && !Objects.equals(opponents.get(attacker.getUniqueId()),v)) e.setCancelled(true);
        }
    }
    @EventHandler public void onJoin(PlayerJoinEvent e) {
        Player p=e.getPlayer();
        if(participants.contains(p.getUniqueId())) title(p,"&6PvPTournament","&fUsa /pvp kit para elegir tu kit");
    }
    @Override public List<String> onTabComplete(CommandSender s,Command c,String alias,String[] a) {
        if(a.length==1) return partial(List.of("ayuda","participante","kit","arena","spawn","modo","iniciar","cancelar","reanudar","cuadro","estadisticas","espectar","lobby"),a[0]);
        if(a.length==2&&a[0].equalsIgnoreCase("participante")) return partial(List.of("añadir","quitar","lista"),a[1]);
        if(a.length==3&&a[0].equalsIgnoreCase("participante")&&(a[1].equalsIgnoreCase("añadir")||a[1].equalsIgnoreCase("quitar"))) return partial(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(),a[2]);
        if(a.length==2&&a[0].equalsIgnoreCase("kit")) return partial(List.of("crear","editar","eliminar"),a[1]);
        if(a.length==3&&a[0].equalsIgnoreCase("kit")) {
            ConfigurationSection sec=getConfig().getConfigurationSection("kits");
            List<String> names=sec==null?new ArrayList<>():new ArrayList<>(sec.getKeys(false));
            if(a[1].equalsIgnoreCase("crear")) names.add("<nombre>");
            return partial(names,a[2]);
        }
        if(a.length==2&&a[0].equalsIgnoreCase("arena")) { ConfigurationSection sec=getConfig().getConfigurationSection("arenas"); List<String> n=sec==null?new ArrayList<>():new ArrayList<>(sec.getKeys(false)); n.add("<nombre>"); return partial(n,a[1]); }
        if(a.length==3&&a[0].equalsIgnoreCase("arena")) return partial(List.of("spawn1","spawn2","espectador","eliminar"),a[2]);
        if(a.length==2&&a[0].equalsIgnoreCase("spawn")) return partial(List.of("lobby","espectador"),a[1]);
        return List.of();
    }
    private List<String> partial(List<String> all,String prefix) { return all.stream().filter(s->s.toLowerCase(Locale.ROOT).startsWith(prefix.toLowerCase(Locale.ROOT))).toList(); }
}
